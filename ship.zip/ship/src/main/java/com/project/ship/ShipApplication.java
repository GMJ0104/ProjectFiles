package com.project.ship;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShipApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShipApplication.class, args);
	}

}
